﻿using Amazon;
using Amazon.SQS;
using Amazon.SQS.Model;
using AWSSQS_example.Models;
using System.Text.Json;
using System.Text.Json.Serialization;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.InputEncoding = System.Text.Encoding.UTF8;

var sqs = new AmazonSQSClient("AKIA3UXZDIPUHAUKVDUY", "D6GzJQoRQosj1yaUdsT+JukqqNFWtM8ZwTEnGQUu", RegionEndpoint.EUCentral1);

var created = await sqs.CreateQueueAsync("support-requests");
var queueUrl = created.QueueUrl;

var jsonOptions = new JsonSerializerOptions
{
    Converters = { new JsonStringEnumConverter() }
};

while (true)
{
    Console.WriteLine();
    Console.WriteLine("1 - Створити заявку");
    Console.WriteLine("2 - Обробити всі заявки");
    Console.WriteLine("3 - Показати приблизну кількість заявок у черзі");
    Console.WriteLine("0 - Вихід");
    Console.Write("Ваш вибір: ");

    var choice = Console.ReadLine();

    if (choice == "1")
    {
        await CreateRequest();
    }
    else if (choice == "2")
    {
        await ProcessAllRequests();
    }
    else if (choice == "3")
    {
        await ShowQueueCount();
    }
    else if (choice == "0")
    {
        break;
    }
    else
    {
        Console.WriteLine("Невірний вибір, спробуйте ще раз.");
    }
}

async Task CreateRequest()
{
    var request = new SupportRequest
    {
        Id = Guid.NewGuid(),
        CreatedAt = DateTime.UtcNow
    };

    Console.Write("Ім'я користувача: ");
    request.UserName = Console.ReadLine() ?? "";

    Console.Write("Тема: ");
    request.Topic = Console.ReadLine() ?? "";

    Console.Write("Опис: ");
    request.Description = Console.ReadLine() ?? "";

    Console.Write("Пріоритет (1 - Low, 2 - Medium, 3 - High): ");
    var p = Console.ReadLine();
    request.Priority = p switch
    {
        "2" => Priority.Medium,
        "3" => Priority.High,
        _ => Priority.Low
    };

    var json = JsonSerializer.Serialize(request, jsonOptions);
    await sqs.SendMessageAsync(queueUrl, json);

    Console.WriteLine($"Заявку №{request.Id} додано в чергу.");
}

async Task ProcessAllRequests()
{
    int processed = 0;

    while (true)
    {
        var resp = await sqs.ReceiveMessageAsync(new ReceiveMessageRequest
        {
            QueueUrl = queueUrl,
            MaxNumberOfMessages = 10,
            WaitTimeSeconds = 2
        });

        if (resp.Messages == null || resp.Messages.Count == 0)
        {
            break;
        }

        foreach (var message in resp.Messages)
        {
            try
            {
                var request = JsonSerializer.Deserialize<SupportRequest>(message.Body, jsonOptions);
                if (request == null)
                {
                    Console.WriteLine("Не вдалося прочитати заявку.");
                    continue;
                }

                var waited = DateTime.UtcNow - request.CreatedAt;

                Console.WriteLine();
                if (request.Priority == Priority.High)
                {
                    Console.WriteLine("Термінова заявка");
                }
                Console.WriteLine($"Заявка №{request.Id}");
                Console.WriteLine($"Користувач: {request.UserName}");
                Console.WriteLine($"Тема: {request.Topic}");
                Console.WriteLine($"Опис: {request.Description}");
                Console.WriteLine($"Пріоритет: {request.Priority}");
                Console.WriteLine($"Очікувала в черзі: {waited.TotalSeconds:F0} с");

                await sqs.DeleteMessageAsync(queueUrl, message.ReceiptHandle);
                processed++;
            }
            catch (JsonException)
            {
                Console.WriteLine("Помилка: повідомлення має неправильний формат JSON.");
            }
        }
    }

    if (processed == 0)
    {
        Console.WriteLine("Черга порожня.");
    }
    else
    {
        Console.WriteLine();
        Console.WriteLine($"Оброблено заявок: {processed}");
    }
}

async Task ShowQueueCount()
{
    var attrs = await sqs.GetQueueAttributesAsync(queueUrl, new List<string> { "ApproximateNumberOfMessages" });
    Console.WriteLine($"Приблизна кількість заявок у черзі: {attrs.ApproximateNumberOfMessages}");
}